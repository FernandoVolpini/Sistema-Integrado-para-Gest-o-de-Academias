package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException; // É bom capturar SQLException especificamente

public class Conexao {
    //PARÂMETROS
    private static final String USUARIO = "postgres";
    private static final String SENHA = "1234"; // Considere externalizar para produção
    private static final String URL = "jdbc:postgresql://127.0.0.1:5432/Academia";
    // private static final String DRIVER = "org.postgresql.Driver"; // Não é estritamente necessário com JDBC 4.0+

    //Estabelecer a conexão entre a APP e o SGBD
    public static Connection conectar(){
        try {
            // Class.forName(DRIVER); // Opcional para drivers JDBC 4.0+
            return DriverManager.getConnection(URL, USUARIO, SENHA);
        } catch (SQLException e) { // Captura SQLException que é mais específica
            System.err.println("ERRO de SQL ao conectar: " + e.getMessage());
            e.printStackTrace(); // Ajuda a debugar
            return null;
        } /*catch (ClassNotFoundException e) { // Se usar Class.forName()
            System.err.println("ERRO: Driver JDBC não encontrado. " + e.getMessage());
            return null;
        }*/
         catch (Exception e) { // Uma captura genérica para outras exceções inesperadas
            System.err.println("ERRO geral ao conectar: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    // TESTAR a CONEXÃO
    public static void main(String[] args) {
        Connection con = Conexao.conectar();
        if (con != null){
            System.out.println("Conexão realizada com sucesso!");
            try {
                con.close(); // Sempre feche a conexão após o uso
                System.out.println("Conexão fechada.");
            } catch (SQLException e) {
                System.err.println("Erro ao fechar a conexão: " + e.getMessage());
            }
        } else {
            System.out.println("Falha na conexão.");
        }
    }

    public static Connection getConnection() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}