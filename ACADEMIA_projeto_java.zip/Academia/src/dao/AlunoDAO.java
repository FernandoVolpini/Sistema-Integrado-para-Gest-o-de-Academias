package dao;

import java.util.ArrayList; // Adicionar esta importação
import java.util.List;      // Adicionar esta importação
import controller.Conexao;
import model.Aluno;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AlunoDAO {

    public boolean inserir(Aluno aluno) {
        if (aluno == null) {
            System.err.println("ERRO no AlunoDAO: Tentativa de inserir um aluno nulo.");
            return false;
        }

        // SQL ajustada para não incluir data_nascimento
        String sql = "INSERT INTO tb_aluno (id_usuario, telefone, endereco, cpf) VALUES (?, ?, ?, ?)";
        
        try (Connection con = Conexao.conectar();
             PreparedStatement cmd = con.prepareStatement(sql)) {

            cmd.setInt(1, aluno.getId());
            cmd.setString(2, aluno.getTelefone());
            cmd.setString(3, aluno.getEndereco());
            cmd.setString(4, aluno.getCpf());

            return cmd.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("ERRO ao inserir aluno: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public boolean usuarioJaExisteComoAluno(int idUsuario) {
        String sql = "SELECT 1 FROM tb_aluno WHERE id_usuario = ?";
        try (Connection con = Conexao.conectar();
             PreparedStatement cmd = con.prepareStatement(sql)) {
            
            cmd.setInt(1, idUsuario);
            try (ResultSet rs = cmd.executeQuery()) {
                return rs.next();
            }

        } catch (SQLException e) {
            System.err.println("ERRO ao verificar aluno: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    public List<Aluno> listarTodosAlunos() {
    // A consulta SQL que une as duas tabelas.
    // Ela pega todos os campos do usuário (u.*) e os campos específicos do aluno (a.*)
    // onde o ID das duas tabelas é o mesmo.
    String sql = "SELECT u.id, u.nome, u.email, u.senha, a.cpf, a.telefone, a.endereco " +
                 "FROM tb_usuario u INNER JOIN tb_aluno a ON u.id = a.id_usuario";

    List<Aluno> listaDeAlunos = new ArrayList<>();

    try (Connection con = Conexao.conectar();
         PreparedStatement cmd = con.prepareStatement(sql);
         ResultSet rs = cmd.executeQuery()) {

        // Itera sobre cada linha que o banco de dados retornou
        while (rs.next()) {
            // Cria um objeto Aluno com todos os dados recuperados
            Aluno aluno = new Aluno(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("email"),
                    rs.getString("senha"),
                    rs.getString("telefone"),
                    rs.getString("endereco"),
                    rs.getString("cpf")
            );
            // Adiciona o aluno criado à lista
            listaDeAlunos.add(aluno);
        }

    } catch (SQLException e) {
        System.err.println("ERRO ao listar alunos: " + e.getMessage());
        e.printStackTrace();
    }

    return listaDeAlunos;
}
    
}