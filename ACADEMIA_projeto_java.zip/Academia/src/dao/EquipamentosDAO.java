package dao;

import model.Equipamentos;
import controller.Conexao;
import model.GrupoMuscular;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class EquipamentosDAO {

    /**
     * Salva ou atualiza um equipamento no banco de dados.
     * @param equipamento O objeto Equipamento a ser salvo.
     */
    public void salvar(Equipamentos equipamento) {
        String sql;
        if (equipamento.getId() == 0) {
            sql = "INSERT INTO equipamentos (nome_equipamento, descricao_exercicio, id_grupo_fk) VALUES (?, ?, ?)";
        } else {
            sql = "UPDATE equipamentos SET nome_equipamento = ?, descricao_exercicio = ?, id_grupo_fk = ? WHERE id_equipamento = ?";
        }

        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, equipamento.getNome());
            ps.setString(2, equipamento.getDescricao());
            ps.setInt(3, equipamento.getGrupoMuscular().getId());

            if (equipamento.getId() != 0) {
                ps.setInt(4, equipamento.getId());
            }

            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Equipamento salvo com sucesso!");

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar equipamento: " + e.getMessage());
        }
    }

    /**
     * Exclui um equipamento do banco de dados pelo seu ID.
     * @param idEquipamento O ID do equipamento a ser excluído.
     */
    public void excluir(int idEquipamento) {
        String sql = "DELETE FROM equipamentos WHERE id_equipamento = ?";

        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idEquipamento);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Equipamento excluído com sucesso!");

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir equipamento: " + e.getMessage());
        }
    }

    /**
     * Busca todos os equipamentos pertencentes a um grupo muscular específico.
     * @param idGrupo O ID do grupo muscular.
     * @return Uma lista de Equipamentos.
     */
    public List<Equipamentos> buscarPorGrupo(int idGrupo) { // <--- CORREÇÃO 1: Nome da classe no singular "Equipamento"
        List<Equipamentos> lista = new ArrayList<>(); // <--- CORREÇÃO 1: Nome da classe no singular "Equipamento"
        String sql = "SELECT * FROM equipamentos WHERE id_grupo_fk = ? ORDER BY nome_equipamento;";

        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, idGrupo);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    // CORREÇÃO 2: Nome da classe e da variável no singular.
                    // A variável "equipamento" representa UM objeto da classe "Equipamento".
                    Equipamentos equipamento = new Equipamentos(); 
                    
                    // CORREÇÃO 3: Chame os métodos na VARIÁVEL (objeto), não na CLASSE.
                    equipamento.setId(rs.getInt("id_equipamento"));
                    equipamento.setNome(rs.getString("nome_equipamento"));
                    equipamento.setDescricao(rs.getString("descricao_exercicio"));
                    
                    // Nota: O objeto GrupoMuscular dentro de equipamento não é preenchido aqui
                    // para manter a consulta simples, conforme o padrão.
                    lista.add(equipamento); // Adiciona o objeto corrigido à lista
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar equipamentos por grupo: " + e.getMessage());
        }
        return lista;
    }

    /**
     * Busca um equipamento específico pelo seu ID para a tela de edição.
     * Este método usa JOIN para trazer também o nome do grupo muscular.
     * @param idEquipamento O ID do equipamento a ser buscado.
     * @return Um objeto Equipamento preenchido, ou null se não encontrar.
     */
    public Equipamentos buscarPorId(int idEquipamento) {
        Equipamentos equipamento = null;
        String sql = "SELECT eq.*, gm.nome_grupo FROM equipamentos eq " +
                     "JOIN grupos_musculares gm ON eq.id_grupo_fk = gm.id_grupo " +
                     "WHERE eq.id_equipamento = ?;";

        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, idEquipamento);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    equipamento = new Equipamentos();
                    equipamento.setId(rs.getInt("id_equipamento"));
                    equipamento.setNome(rs.getString("nome_equipamento"));
                    equipamento.setDescricao(rs.getString("descricao_exercicio"));
                    
                    GrupoMuscular grupo = new GrupoMuscular();
                    grupo.setId(rs.getInt("id_grupo_fk"));
                    grupo.setNome(rs.getString("nome_grupo"));
                    
                    equipamento.setGrupoMuscular(grupo);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar equipamento por ID: " + e.getMessage());
        }
        return equipamento;
    }
}