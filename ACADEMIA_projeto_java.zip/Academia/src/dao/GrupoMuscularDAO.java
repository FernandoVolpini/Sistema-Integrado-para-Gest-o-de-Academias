package dao;

import model.GrupoMuscular;
import controller.Conexao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class GrupoMuscularDAO {

    public List<GrupoMuscular> listarTodos() {
        List<GrupoMuscular> lista = new ArrayList<>();
        String sql = "SELECT * FROM grupos_musculares ORDER BY nome_grupo;";

        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                GrupoMuscular grupo = new GrupoMuscular();
                grupo.setId(rs.getInt("id_grupo"));
                grupo.setNome(rs.getString("nome_grupo"));
                lista.add(grupo);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar grupos musculares: " + e.getMessage());
        }
        return lista;
    }
}