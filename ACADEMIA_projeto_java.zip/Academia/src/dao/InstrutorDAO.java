package dao;

import controller.Conexao; // Sua classe de conexão
import model.Instrutor;   // Sua classe de modelo Instrutor
import model.Usuario;     // Classe pai (para referência)

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe DAO para realizar as operações de persistência para a entidade Instrutor,
 * seguindo o padrão estabelecido por AlunoDAO.
 */
public class InstrutorDAO {

    /**
     * Insere os dados específicos do instrutor na tabela tb_instrutor.
     * Este método deve ser chamado DEPOIS que um Usuario já foi inserido na tb_usuario.
     * * @param instrutor O objeto Instrutor contendo os dados a serem inseridos.
     * O ID do instrutor já deve corresponder a um registro em tb_usuario.
     * @return true se a inserção for bem-sucedida, false caso contrário.
     */
    public boolean inserir(Instrutor instrutor) {
        if (instrutor == null) {
            System.err.println("ERRO no InstrutorDAO: Tentativa de inserir um instrutor nulo.");
            return false;
        }

        // SQL para inserir os dados específicos na tabela de instrutores.
        String sql = "INSERT INTO tb_instrutor (id_usuario, especialidade, cref, dataContratacao) VALUES (?, ?, ?, ?)";
        
        try (Connection con = Conexao.conectar();
             PreparedStatement cmd = con.prepareStatement(sql)) {

            // Define os parâmetros da consulta com os dados do objeto Instrutor.
            cmd.setInt(1, instrutor.getId()); // Usa o ID herdado de Usuario.
            cmd.setString(2, instrutor.getEspecialidade());
            cmd.setString(3, instrutor.getCref());
            cmd.setInt(4, instrutor.getDataContratacao());

            // Executa o comando e retorna true se alguma linha foi afetada.
            return cmd.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("ERRO ao inserir instrutor: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Verifica se um ID de usuário já está associado a um registro na tabela de instrutores.
     * Útil para evitar duplicação de papéis.
     * * @param idUsuario O ID do usuário a ser verificado.
     * @return true se o usuário já for um instrutor, false caso contrário.
     */
    public boolean usuarioJaExisteComoInstrutor(int idUsuario) {
        String sql = "SELECT 1 FROM tb_instrutor WHERE id_usuario = ?";
        
        try (Connection con = Conexao.conectar();
             PreparedStatement cmd = con.prepareStatement(sql)) {
            
            cmd.setInt(1, idUsuario);
            
            try (ResultSet rs = cmd.executeQuery()) {
                // Se rs.next() for verdadeiro, significa que encontrou um registro.
                return rs.next();
            }

        } catch (SQLException e) {
            System.err.println("ERRO ao verificar instrutor: " + e.getMessage());
            e.printStackTrace();
            return false; // Retorna false em caso de erro para evitar lógicas incorretas.
        }
    }
    
    /**
     * Lista todos os instrutores cadastrados no sistema, combinando dados
     * das tabelas de usuário e instrutor.
     * * @return Uma lista de objetos Instrutor.
     */
    public List<Instrutor> listarTodosInstrutores() {
        // SQL que une as tabelas tb_usuario e tb_instrutor para obter todos os dados.
        String sql = "SELECT u.id, u.nome, u.email, u.senha, u.dataCadastro, " +
                     "i.especialidade, i.cref, i.dataContratacao " +
                     "FROM tb_usuario u INNER JOIN tb_instrutor i ON u.id = i.id_usuario";

        List<Instrutor> listaDeInstrutores = new ArrayList<>();

        try (Connection con = Conexao.conectar();
             PreparedStatement cmd = con.prepareStatement(sql);
             ResultSet rs = cmd.executeQuery()) {

            // Itera sobre cada resultado da consulta.
            while (rs.next()) {
                // Cria um objeto Instrutor com os dados recuperados do banco.
                Instrutor instrutor = new Instrutor(
                    // Atributos de Usuario
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("email"),
                    rs.getString("senha"),
                    rs.getInt("dataCadastro"), // Assumindo que dataCadastro existe em tb_usuario

                    // Atributos específicos de Instrutor
                    rs.getString("especialidade"),
                    rs.getString("cref"),
                    rs.getInt("dataContratacao")
                );
                
                // Adiciona o instrutor populado à lista.
                listaDeInstrutores.add(instrutor);
            }

        } catch (SQLException e) {
            System.err.println("ERRO ao listar instrutores: " + e.getMessage());
            e.printStackTrace();
        }

        return listaDeInstrutores;
    }

    // Você pode adicionar aqui os métodos de editar() e excluir() seguindo o mesmo padrão.
}