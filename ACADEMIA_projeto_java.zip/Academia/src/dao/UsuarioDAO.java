package dao;

import controller.Conexao;
import model.Usuario;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {

    /**
     * Insere um usuário no banco de dados.
     */
    public int inserir(Usuario usuario) {
        String sql = "INSERT INTO tb_usuario (nome, email, senha) VALUES (?, ?, ?)";
        try (Connection con = Conexao.conectar();
             PreparedStatement cmd = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            cmd.setString(1, usuario.getNome());
            cmd.setString(2, usuario.getEmail());
            cmd.setString(3, usuario.getSenha());

            if (cmd.executeUpdate() > 0) {
                try (ResultSet rs = cmd.getGeneratedKeys()) {
                    if (rs.next()) {
                        return rs.getInt(1); // Retorna o ID gerado
                    }
                }
            }
            return -1;
        } catch (SQLException e) {
            System.err.println("ERRO ao inserir usuário: " + e.getMessage());
            e.printStackTrace();
            return -1;
        }
    }

    /**
     * Atualiza um usuário no banco de dados.
     */
    public int atualizar(Usuario a) {
        String sql = "UPDATE tb_usuario SET nome = ?, email = ?, senha = ? WHERE id = ?";
        try (Connection con = Conexao.conectar();
             PreparedStatement cmd = con.prepareStatement(sql)) {

            cmd.setString(1, a.getNome());
            cmd.setString(2, a.getEmail());
            cmd.setString(3, a.getSenha());
            cmd.setInt(4, a.getId());

            return cmd.executeUpdate();
        } catch (SQLException e) {
            System.err.println("ERRO ao atualizar usuário: " + e.getMessage());
            e.printStackTrace();
            return 0;
        }
    }

    public List<Usuario> pesquisarPorId(int id) {
        List<Usuario> lista = new ArrayList<>();
        String sql = "SELECT id, nome, email, senha FROM tb_usuario WHERE id = ? ORDER BY id";
        try (Connection con = Conexao.conectar();
             PreparedStatement cmd = con.prepareStatement(sql)) {

            cmd.setInt(1, id);
            ResultSet rs = cmd.executeQuery();
            while (rs.next()) {
                Usuario a = new Usuario(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("email"),
                    rs.getString("senha")
                );
                lista.add(a);
            }
        } catch (SQLException e) {
            System.err.println("ERRO ao pesquisar por ID: " + e.getMessage());
            e.printStackTrace();
        }
        return lista;
    }

    public List<Usuario> pesquisarPorNome(String nome) {
        List<Usuario> lista = new ArrayList<>();
        String sql = "SELECT id, nome, email, senha FROM tb_usuario WHERE nome ILIKE ? ORDER BY nome";
        try (Connection con = Conexao.conectar();
             PreparedStatement cmd = con.prepareStatement(sql)) {

            cmd.setString(1, "%" + nome + "%");
            ResultSet rs = cmd.executeQuery();
            while (rs.next()) {
                lista.add(new Usuario(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("email"),
                    rs.getString("senha")
                ));
            }
        } catch (SQLException e) {
            System.err.println("ERRO ao pesquisar usuários por nome: " + e.getMessage());
            e.printStackTrace();
        }
        return lista;
    }

    public List<Usuario> listarTodos() {
        List<Usuario> lista = new ArrayList<>();
        String sql = "SELECT id, nome, email, senha FROM tb_usuario ORDER BY nome";
        try (Connection con = Conexao.conectar();
             PreparedStatement cmd = con.prepareStatement(sql);
             ResultSet rs = cmd.executeQuery()) {

            while (rs.next()) {
                lista.add(new Usuario(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("email"),
                    rs.getString("senha")
                ));
            }
        } catch (SQLException e) {
            System.err.println("ERRO ao listar todos os usuários: " + e.getMessage());
            e.printStackTrace();
        }
        return lista;
    }
    
    public Usuario buscarPorCpf(String cpf) {
    String sql = "SELECT * FROM usuario WHERE cpf = ?";
    try (Connection conn = Conexao.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setString(1, cpf);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            Usuario u = new Usuario();
            u.setId(rs.getInt("id"));
            u.setNome(rs.getString("nome"));
            u.setEmail(rs.getString("email"));
            u.setSenha(rs.getString("senha"));
            // Adicione se o campo existir:
            // u.setCpf(rs.getString("cpf"));
            return u;
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }
    return null;
}
    /**
     * Busca um usuário pelo seu número de CREF.
     * @param cref O CREF a ser buscado.
     * @return um objeto Usuario se encontrado, ou null caso contrário.
     */
    public Usuario buscarPorCref(String cref) {
        String sql = "SELECT * FROM usuario WHERE cref = ?"; // Supondo que a coluna se chama 'cref'
        Usuario usuario = null;
        
        try (Connection conn = Conexao.getConnection(); // Obtenha sua conexão
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, cref);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    usuario = new Usuario();
                    usuario.setId(rs.getInt("id"));
                    usuario.setNome(rs.getString("nome"));
                    usuario.setEmail(rs.getString("email"));
                    usuario.setCref(rs.getString("cref")); // Supondo que seu modelo Usuario tem um campo para o CREF
                    // Preencha os outros campos do usuário, exceto a senha
                }
            }
        } catch (Exception e) {
            e.printStackTrace(); 
            // Em uma aplicação real, trate o erro de forma mais robusta
        }
        
        return usuario;
    }
}
