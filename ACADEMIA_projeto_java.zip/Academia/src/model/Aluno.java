package model;

public class Aluno extends Usuario {

    private String telefone;
    private String endereco;
    private String cpf;

    public Aluno() {
        super();
    }

    public Aluno(
            // Atributos herdados de Usuario
            int id, String nome, String email, String senha,

            // Atributos específicos de Aluno
            String telefone, String endereco, String cpf
    ) {
        super(id, nome, email, senha);
        this.telefone = telefone;
        this.endereco = endereco;
        this.cpf = cpf;
    }

    // --- Getters e Setters ---

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    @Override
    public String toString() {
        return super.toString() + " | Aluno [" + "telefone='" + telefone + '\'' + ", endereco='" + endereco + '\'' + ", cpf='" + cpf + '\'' + ']';
    }
}