package model;

// PACOTE_DO_SEU_PROJETO.model; // (ou onde você salvou sua classe)

public class GrupoMuscular {
    private int id;
    private String nome;

    // Construtor vazio
    public GrupoMuscular() {
    }

    // Construtor com parâmetros (opcional, mas útil)
    public GrupoMuscular(int id, String nome) {
        this.id = id;
        this.nome = nome;
    }

    // --- Getters e Setters ---
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * Este método é muito importante.
     * É ele que faz o JComboBox exibir o nome do grupo muscular corretamente.
     */
    @Override
    public String toString() {
        return this.nome;
    }
}