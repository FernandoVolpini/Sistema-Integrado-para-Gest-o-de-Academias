package model;

public class Instrutor extends Usuario { // Instrutor HERDA de Usuario

    private String especialidade; // e.g., "Musculação", "Pilates", "Yoga"
    private String cref;          // Número de registro no Conselho Regional de Educação Física
    private int dataContratacao;  // Data de contratação, no formato int (como outros campos de data)

    // Construtor padrão
    public Instrutor() {
        super(); // Chama o construtor padrão da classe pai (Usuario)
    }

    // Construtor sobrecarregado (da classe Usuario e da classe Instrutor)
    public Instrutor(
            // Atributos herdados de Usuario
            int id,
            String nome,
            String email,
            String senha,
            int dataCadastro, // dataCadastro é um atributo de Usuario

            // Atributos específicos de Instrutor
            String especialidade,
            String cref,
            int dataContratacao
    ) {
        // Chama o construtor da classe pai (Usuario)
        // Assumindo que o construtor de Usuario é:
        // Usuario(int id, String nome, String email, String senha, String tipoUsuario, int dataCadastro)
        super(id, nome, email, senha); // Define "instrutor" como tipoUsuario

        this.especialidade = especialidade;
        this.cref = cref;
        this.dataContratacao = dataContratacao;
    }

    // Getters e Setters para os atributos específicos de Instrutor

    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    public String getCref() {
        return cref;
    }

    public void setCref(String cref) {
        this.cref = cref;
    }

    public int getDataContratacao() {
        return dataContratacao;
    }

    public void setDataContratacao(int dataContratacao) {
        this.dataContratacao = dataContratacao;
    }

    // Método toString (sobrescrevendo o de Usuario e adicionando informações de Instrutor)
    @Override
    public String toString() {
        // Chama o toString() da classe pai e adiciona os detalhes do Instrutor
        return super.toString() + " | Instrutor [" + "especialidade='" + especialidade + '\'' + ", cref='" + cref + '\'' + ", dataContratacao=" + dataContratacao + ']';
    }
}