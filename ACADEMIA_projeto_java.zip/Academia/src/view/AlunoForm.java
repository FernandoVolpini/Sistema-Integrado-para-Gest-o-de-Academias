package view;

import dao.AlunoDAO;
import model.Aluno;
import model.Usuario;

import javax.swing.*;
import java.util.List;

public class AlunoForm extends javax.swing.JFrame {

    private final AlunoDAO alunoDAO;

    public AlunoForm() {
        initComponents();
        this.setLocationRelativeTo(null); // Centraliza a janela
        this.alunoDAO = new AlunoDAO();

        // <-- CORREÇÃO: Configura o ComboBox para aceitar objetos Usuario.
        // Isso remove a necessidade da linha cbxUsuario.setModel(...) que estava no initComponents.
        cbxUsuario.setModel(new DefaultComboBoxModel<>());

        carregarAlunos();

        // O listener do botão salvar já é adicionado pelo NetBeans no initComponents,
        // então a adição manual no construtor foi removida para evitar duplicação.
    }

   private void carregarAlunos() {
    cbxUsuario.removeAllItems(); // Limpa a lista

    // Chama o novo método do DAO para buscar a lista de alunos
    List<Aluno> alunos = alunoDAO.listarTodosAlunos();

    // Adiciona cada aluno encontrado ao ComboBox
    for (Aluno a : alunos) {
        // É possível adicionar um Aluno a um JComboBox<Usuario>
        // porque Aluno HERDA de Usuario (polimorfismo).
        cbxUsuario.addItem(a);
    }
    
    

    }


    /**
     * SUGESTÃO: Para o ComboBox mostrar o nome do usuário, vá na sua classe Usuario
     * e adicione este método.
     *
     * @Override
     * public String toString() {
     * return this.getNome(); // Retorna o nome do usuário para exibição
     * }
     */

    // --- CÓDIGO GERADO PELO NETBEANS (sem modificações manuais necessárias aqui) ---
    @SuppressWarnings("unchecked")
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cbxUsuario = new javax.swing.JComboBox<>();
        txtCPF = new javax.swing.JTextField();
        btnSalvar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        cbxUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxUsuarioActionPerformed(evt);
            }
        });

        txtCPF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCPFActionPerformed(evt);
            }
        });

        btnSalvar.setText("Salvar");
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel1.setText("Insira seu CPF");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtCPF, javax.swing.GroupLayout.PREFERRED_SIZE, 316, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbxUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(135, 135, 135)
                        .addComponent(btnSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(46, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(cbxUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGap(14, 14, 14)
                .addComponent(txtCPF, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(btnSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(57, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtCPFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCPFActionPerformed
        // Simula um clique no botão Salvar.
    // Isso executará toda a lógica que você já escreveu no método btnSalvarActionPerformed.
    btnSalvar.doClick();
    }//GEN-LAST:event_txtCPFActionPerformed

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed
       // 1. Pega o objeto Usuario completo que foi selecionado no ComboBox
    Usuario usuarioSelecionado = (Usuario) cbxUsuario.getSelectedItem();

    // 2. Pega o texto do CPF e remove espaços em branco
    String cpf = txtCPF.getText().trim();

    // 3. Validações
    if (usuarioSelecionado == null) {
        JOptionPane.showMessageDialog(this, "Nenhum usuário disponível ou selecionado!", "Aviso", JOptionPane.WARNING_MESSAGE);
        return;
    }
    if (cpf.isEmpty()) {
        JOptionPane.showMessageDialog(this, "O campo CPF é obrigatório.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // 4. Cria o objeto Aluno e preenche com os dados da tela ( VERSÃO CORRIGIDA )
    // ✅ Usa o construtor de Aluno, passando os dados herdados do usuário selecionado
    //    e os dados específicos do aluno (CPF) vindos da tela.
    Aluno novoAluno = new Aluno(
            usuarioSelecionado.getId(),
            usuarioSelecionado.getNome(),
            usuarioSelecionado.getEmail(),
            usuarioSelecionado.getSenha(),
            null, // Telefone (não temos na tela, então passamos nulo)
            null, // Endereço (não temos na tela, então passamos nulo)
            cpf   // CPF que o usuário digitou
    );

    // 5. Tenta inserir no banco de dados
    boolean sucesso = alunoDAO.inserir(novoAluno);

    // 6. Mostra o resultado para o usuário
    if (sucesso) {
        JOptionPane.showMessageDialog(this, "Aluno cadastrado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        txtCPF.setText(""); // Limpa o campo de CPF
        carregarAlunos(); // Atualiza a lista, removendo o usuário que virou aluno
    } else {
        JOptionPane.showMessageDialog(this, "Falha ao cadastrar aluno.\nVerifique se o CPF já existe ou se há um erro no sistema.", "Erro no Banco de Dados", JOptionPane.ERROR_MESSAGE);
    }
    
    }//GEN-LAST:event_btnSalvarActionPerformed

    private void cbxUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxUsuarioActionPerformed
 // Pega o item que foi selecionado na lista
    Object itemSelecionado = cbxUsuario.getSelectedItem();

    // Verifica se o item selecionado é de fato um Aluno
    if (itemSelecionado instanceof Aluno aluno) {

        // Preenche o campo de texto com o CPF do aluno selecionado
        txtCPF.setText(aluno.getCpf());

        // Se você tivesse campos para telefone ou endereço, preencheria aqui também:
        // txtTelefone.setText(aluno.getTelefone());
        // txtEndereco.setText(aluno.getEndereco());
    } else {
        // Se, por algum motivo, o item não for um aluno (ex: lista vazia), limpa o campo
        txtCPF.setText("");
    }
    }//GEN-LAST:event_cbxUsuarioActionPerformed

   
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            new AlunoForm().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSalvar;
    private javax.swing.JComboBox<model.Usuario> cbxUsuario;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JTextField txtCPF;
    // End of variables declaration//GEN-END:variables
}
